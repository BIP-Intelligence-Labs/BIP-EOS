"""UEOS Runtime Bootstrap"""
